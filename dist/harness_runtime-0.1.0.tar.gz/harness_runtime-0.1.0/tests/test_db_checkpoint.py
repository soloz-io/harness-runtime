"""Business integration tests — real CLI, real DB, mock or real LLM.

Tests the harness-runtime CLI as a black box (same as SDK usage):
  1. Spawn subprocess
  2. Send control_request {initialize} + user {message} via stdin
  3. Read LiteLLM frames from stdout
  4. Validate frame sequence and shape
  5. Query PostgreSQL directly for checkpoint persistence

Two modes via USE_MOCK_LLM env var (same assertions):
  - mock (default): fast, deterministic, no API key needed
  - real: exercises real LLM calls, requires API keys + longer timeout
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

import psycopg
import pytest

MOCK_DATA = Path(__file__).parent / "mock" / "simple-bug-fix-invoke-requests.json"
TIMEOUT = int(os.getenv("TEST_TIMEOUT", "120"))
DB_URL = os.getenv("DATABASE_URL", "")

pytestmark = [
    pytest.mark.skipif(not DB_URL, reason="DATABASE_URL not set"),
]


def _is_mock_mode() -> bool:
    return os.getenv("USE_MOCK_LLM", "true").lower() == "true"


def _harness_command() -> list[str]:
    """Try harness-runtime CLI, then fall back to python -m cli."""
    import shutil
    cli = shutil.which("harness-runtime")
    if cli:
        return [cli]
    return [sys.executable, str(Path(__file__).parent / "cli.py")]


def _spawn() -> subprocess.Popen[bytes]:
    cmd = _harness_command()
    env = {
        **os.environ,
        "DATABASE_URL": DB_URL,
        "PYTHONUNBUFFERED": "1",
    }
    if _is_mock_mode():
        env["USE_MOCK_LLM"] = "true"
    return subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def _send(proc: subprocess.Popen[bytes], obj: dict[str, Any]) -> None:
    assert proc.stdin is not None
    proc.stdin.write(json.dumps(obj).encode() + b"\n")
    proc.stdin.flush()


def _read_frame(proc: subprocess.Popen[bytes]) -> dict[str, Any]:
    assert proc.stdout is not None
    line = proc.stdout.readline()
    if not line:
        raise EOFError("stdout closed unexpectedly")
    return json.loads(line)


def _read_turn(proc: subprocess.Popen[bytes]) -> list[dict[str, Any]]:
    frames: list[dict[str, Any]] = []
    while True:
        frame = _read_frame(proc)
        frames.append(frame)
        if frame.get("type") == "result":
            break
    return frames


def _count_checkpoints(session_id: str) -> int:
    with psycopg.connect(DB_URL) as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT COUNT(*) FROM checkpoints WHERE thread_id = %s",
                (session_id,),
            )
            return cur.fetchone()[0]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_single_turn_produces_frames_and_checkpoint() -> None:
    """Full turn lifecycle: frames match LiteLLM spec + checkpoint written."""
    payloads = json.loads(MOCK_DATA.read_text())
    step = list(payloads["requests"].values())[0]
    user_content = step["input_payload"]["messages"][0]["content"]

    proc = _spawn()
    try:
        _send(proc, {
            "type": "control_request",
            "request_id": "req_1",
            "request": {
                "subtype": "initialize",
                "agent_definition": step["agent_definition"],
                "input_payload": step["input_payload"],
            },
        })
        init_resp = _read_frame(proc)
        assert init_resp["type"] == "control_response"
        assert init_resp["response"]["subtype"] == "success"
        session_id = init_resp["response"]["session_id"]

        _send(proc, {
            "type": "user",
            "message": {"role": "user", "content": user_content},
            "session_id": None,
            "parent_tool_use_id": None,
        })

        frames = _read_turn(proc)

        assert frames[0]["type"] == "system"
        assert frames[0]["subtype"] == "init"
        assert frames[0]["session_id"] == session_id

        assistant_frames = [f for f in frames if f["type"] == "assistant"]
        assert len(assistant_frames) >= 1

        assert frames[-1]["type"] == "result"
        assert frames[-1]["subtype"] == "success"
        assert frames[-1]["duration_ms"] > 0
        assert frames[-1]["is_error"] is False
        assert frames[-1]["num_turns"] >= 1
        assert frames[-1]["session_id"] == session_id

        count = _count_checkpoints(session_id)
        assert count >= 1, f"Expected >=1 checkpoint for {session_id}, got {count}"
    finally:
        proc.stdin.close()
        proc.wait(timeout=TIMEOUT)


def test_multi_turn_persists_state() -> None:
    """Two turns in one session: both produce frames + checkpoints accumulate."""
    payloads = json.loads(MOCK_DATA.read_text())
    steps = list(payloads["requests"].values())[:2]

    proc = _spawn()
    try:
        _send(proc, {
            "type": "control_request",
            "request_id": "req_1",
            "request": {
                "subtype": "initialize",
                "agent_definition": steps[0]["agent_definition"],
                "input_payload": steps[0]["input_payload"],
            },
        })
        init_resp = _read_frame(proc)
        session_id = init_resp["response"]["session_id"]

        for i, step in enumerate(steps):
            content = step["input_payload"]["messages"][0]["content"]
            _send(proc, {
                "type": "user",
                "message": {"role": "user", "content": content},
                "session_id": session_id,
                "parent_tool_use_id": None,
            })
            frames = _read_turn(proc)
            assert frames[-1]["type"] == "result"
            assert frames[-1]["num_turns"] == i + 1

        count = _count_checkpoints(session_id)
        assert count >= len(steps), (
            f"Expected >= {len(steps)} checkpoints for {session_id}, got {count}"
        )
    finally:
        proc.stdin.close()
        proc.wait(timeout=TIMEOUT)


def test_result_frame_on_error() -> None:
    """Malformed initialize → error result frame."""
    proc = _spawn()
    try:
        _send(proc, {
            "type": "user",
            "message": {"role": "user", "content": "hello"},
            "session_id": None,
            "parent_tool_use_id": None,
        })
        frames = _read_turn(proc)
        assert frames[-1]["type"] == "result"
        assert frames[-1]["is_error"] is True
    finally:
        proc.stdin.close()
        proc.wait(timeout=TIMEOUT)
